# Diabetes Prediction using Machine Learning
Prediction of Probability of Diabetes using Logistic Regression algorithm and Deployed using Flask and Heroku.<BR>
Heres's the Heroku [link](https://diabetes-probability.herokuapp.com/)

## Medium Post
Here's a [link](https://link.medium.com/9H5DBhZ8a5) to the blog post where I explained the processes involved in developing this application.
## Screenshot of Diabetes Prediction Page
![ScreenShot](https://res.cloudinary.com/kemmie/image/upload/v1585215977/homepage_gpo2p7.jpg)
